#include <stdio.h>
#include <stdlib.h>

double * creerMatrice(int n)
{
    double * A = malloc (n * n * sizeof(*A));

    if (A == NULL)
    {
        printf("Erreur d'allocation");
        exit(EXIT_FAILURE);
    }

    return A;
}

void detruireMatrice(double * A)
{
    free(A);
}

void afficherMatrice(int n, double * A){

    for(int i=0;i<n;i++){

        for(int j=0;j<n;j++){

            printf(" %5.2lf ",A[i*n+j] );

        }

        printf("\n");

    }

}

double * somme2Matrices(int n, double * A, double * B){

    double * res = creerMatrice(n);

    for(int i=0;i<n;i++){

        for(int j=0;j<n;j++){

            res[i*n+j]=A[i*n+j]+B[i*n+j];

        }

    }
    return res;
}

double * produitReelMatrice(int n, double r, double * A){

    double * res= creerMatrice(n);

    for(int i=0;i<n;i++){

        for(int j=0;j<n;j++){

            res[i*n+j]=A[i*n+j]* r;

        }

    }
    return res;
}

double * produit2Matrices(int n, double * A, double * B){

    double * res = creerMatrice(n);

    for(int i=0;i<n;i++){

        for(int j=0;j<n;j++){

            res[i*n+j]=0;

            for(int k=0;k<n;k++){

                res[i*n+j]+=A[i*n+k] * B[k*n+j];

            }

        }

    }
    return res;
}

double * copieMatrice(int n, double * A){

    double * res = creerMatrice(n);

    for(int i = 0 ;i<n;i++){

        for(int j = 0;j<n;j++){

            res[i*n+j] = A[i*n+j];
        }

    }

    return res ;

}

double * transposeeMatrice(int n, double * A){

    double * res = creerMatrice(n);

    for(int i=0;i<n;i++){

        for(int j=0;j<n;j++){

            res[j*n+i]=A[i*n+j];

        }

    }
    return res;
}

double * matriceSansLC(int n, double * A, int L, int C){
    int x=0;
    double * res =creerMatrice(n-1);

    for(int i=0;i<n;i++){

        for(int j=0 ; j<n ; j++){

            if(j!=C && i!=L){
                res[x]=A[i*n+j];
                x++;

            }

        }

    }
    return res;
}

double determinant(int taille, double* A){

    double * sousMatrice ;
    int signe=1;
    double res = 0;

    if(taille==1){
        return A[0];
    }

    for(int i=0;i<taille;i++){
        sousMatrice=matriceSansLC(taille,A,0,i);
        res+=signe * A[i] * determinant(taille-1,sousMatrice);
        signe*=-1;
    }
    
    return res;
}

double * comatrice(int n, double * A){
    double * sousmatrice;
    double * res = creerMatrice(n);
    int signe=1;
    for(int i = 0;i<n;i++){
        for (int j=0;j<n;j++){
            sousmatrice=matriceSansLC(n,A,i,j);
            res[i*n+j]=signe*determinant(n-1,sousmatrice);
            detruireMatrice(sousmatrice);
            signe*=-1;
        }
    }
    return res;
}


double * inverserMatrice(int n, double * A){
    double * commat=comatrice(n,A);
    double * commatTranspo = transposeeMatrice(n,commat);
    detruireMatrice(commat);
    double det = determinant(n,A);
    double * res = produitReelMatrice(3,(1/det),commatTranspo);
    detruireMatrice(commatTranspo);
    return res;
}